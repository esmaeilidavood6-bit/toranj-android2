package ir.narenj.toranj

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import java.text.DecimalFormat

private val Forest = Color(0xFF123B2C)
private val Forest2 = Color(0xFF1B513D)
private val Gold = Color(0xFFD6AD55)
private val Cream = Color(0xFFF5F1E7)
private val Muted = Color(0xFF9EAA9F)
private val Brown = Color(0xFF76502F)
private fun money(v: Long) = DecimalFormat("#,###").format(v) + " تومان"

data class MenuItem(val id: Long, val name: String, val price: Long, val category: String)
data class TableInfo(val number: Int, val total: Long, val count: Int)
data class StockItem(val id: Long, val name: String, val quantity: Double, val unit: String)

class ToranjDb(context: Context) : SQLiteOpenHelper(context, "toranj.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,price INTEGER NOT NULL,category TEXT NOT NULL)")
        db.execSQL("CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT,table_no INTEGER NOT NULL,status TEXT NOT NULL,created_at INTEGER NOT NULL,order_type TEXT NOT NULL DEFAULT 'حضوری')")
        db.execSQL("CREATE TABLE order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,product_id INTEGER NOT NULL,name TEXT NOT NULL,price INTEGER NOT NULL,qty INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE stock(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,qty REAL NOT NULL,unit TEXT NOT NULL)")
        db.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,amount INTEGER NOT NULL,created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT NOT NULL)")
        seed(db)
    }
    private fun seed(db: SQLiteDatabase) {
        val samples = listOf(
            Triple("چای", 45000L, "نوشیدنی"), Triple("قهوه فرانسه", 95000L, "نوشیدنی"),
            Triple("لاته", 125000L, "نوشیدنی"), Triple("آب معدنی", 25000L, "نوشیدنی"),
            Triple("چلو جوجه", 285000L, "غذا"), Triple("چلو کباب", 390000L, "غذا"),
            Triple("سیب‌زمینی", 110000L, "پیش‌غذا"), Triple("قلیان", 250000L, "قلیان")
        )
        samples.forEach { (n,p,c) -> db.insert("products", null, ContentValues().apply { put("name",n); put("price",p); put("category",c) }) }
        listOf(Triple("چای خشک", 2.0, "کیلوگرم"), Triple("قهوه", 1.0, "کیلوگرم"), Triple("مرغ", 5.0, "کیلوگرم"), Triple("برنج", 10.0, "کیلوگرم")).forEach { (n,q,u) ->
            db.insert("stock", null, ContentValues().apply { put("name",n); put("qty",q); put("unit",u) })
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Versioned schema migration placeholder; current v2 preserves existing records.
    }
    fun products(): List<MenuItem> = readableDatabase.rawQuery("SELECT id,name,price,category FROM products ORDER BY category,name", null).use { c ->
        buildList { while(c.moveToNext()) add(MenuItem(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3))) }
    }
    fun tables(): List<TableInfo> = (1..20).map { n ->
        val q = readableDatabase.rawQuery("SELECT COALESCE(SUM(oi.price*oi.qty),0),COALESCE(SUM(oi.qty),0) FROM orders o LEFT JOIN order_items oi ON oi.order_id=o.id WHERE o.table_no=? AND o.status='open'", arrayOf(n.toString()))
        q.use { if(it.moveToFirst()) TableInfo(n,it.getLong(0),it.getInt(1)) else TableInfo(n,0,0) }
    }
    fun activeOrder(table: Int): Long {
        val c = readableDatabase.rawQuery("SELECT id FROM orders WHERE table_no=? AND status='open' ORDER BY id DESC LIMIT 1", arrayOf(table.toString()))
        c.use { if(it.moveToFirst()) return it.getLong(0) }
        return writableDatabase.insert("orders", null, ContentValues().apply { put("table_no",table); put("status","open"); put("created_at",System.currentTimeMillis()); put("order_type","حضوری") })
    }
    fun addItem(table: Int, item: MenuItem) {
        val order = activeOrder(table)
        writableDatabase.insert("order_items", null, ContentValues().apply { put("order_id",order); put("product_id",item.id); put("name",item.name); put("price",item.price); put("qty",1) })
    }
    fun orderLines(table: Int): List<Pair<String, Pair<Int, Long>>> {
        return readableDatabase.rawQuery("SELECT oi.name,SUM(oi.qty),SUM(oi.price*oi.qty) FROM orders o JOIN order_items oi ON oi.order_id=o.id WHERE o.table_no=? AND o.status='open' GROUP BY oi.name", arrayOf(table.toString())).use { c ->
            buildList { while(c.moveToNext()) add(c.getString(0) to (c.getInt(1) to c.getLong(2))) }
        }
    }
    fun total(table: Int): Long = orderLines(table).sumOf { it.second.second }
    fun closeOrder(table: Int, servicePercent: Int, entryFee: Long): Long {
        val order = activeOrder(table)
        val subtotal = total(table)
        val service = subtotal * servicePercent / 100
        val final = subtotal + service + entryFee
        writableDatabase.execSQL("UPDATE orders SET status='paid' WHERE id=?", arrayOf(order))
        return final
    }
    fun addStock(name: String, qty: Double, unit: String) {
        val c = writableDatabase.rawQuery("SELECT id FROM stock WHERE name=?", arrayOf(name))
        val id = c.use { if(it.moveToFirst()) it.getLong(0) else -1L }
        if(id >= 0) writableDatabase.execSQL("UPDATE stock SET qty=qty+? WHERE id=?", arrayOf(qty,id))
        else writableDatabase.insert("stock",null,ContentValues().apply { put("name",name); put("qty",qty); put("unit",unit) })
    }
    fun stock(): List<StockItem> = readableDatabase.rawQuery("SELECT id,name,qty,unit FROM stock ORDER BY name",null).use { c ->
        buildList { while(c.moveToNext()) add(StockItem(c.getLong(0),c.getString(1),c.getDouble(2),c.getString(3))) }
    }
    fun addExpense(title: String, amount: Long) {
        writableDatabase.insert("expenses",null,ContentValues().apply { put("title",title); put("amount",amount); put("created_at",System.currentTimeMillis()) })
    }
    fun expenseTotal(): Long = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM expenses",null).use { if(it.moveToFirst()) it.getLong(0) else 0 }
    fun salesTotal(): Long = readableDatabase.rawQuery("SELECT COALESCE(SUM(oi.price*oi.qty),0) FROM orders o JOIN order_items oi ON oi.order_id=o.id WHERE o.status='paid'",null).use { if(it.moveToFirst()) it.getLong(0) else 0 }
    fun addProduct(name: String, price: Long, category: String) {
        writableDatabase.insert("products",null,ContentValues().apply { put("name",name); put("price",price); put("category",category) })
    }
    fun setRole(role: String) { writableDatabase.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES('role',?)", arrayOf(role)) }
    fun role(): String = readableDatabase.rawQuery("SELECT v FROM settings WHERE k='role'",null).use { if(it.moveToFirst()) it.getString(0) else "مدیر" }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = ToranjDb(this)
        setContent { ToranjApp(db) }
    }
}

@Composable
fun ToranjApp(db: ToranjDb) {
    var page by remember { mutableStateOf("خانه") }
    var refresh by remember { mutableIntStateOf(0) }
    var selectedTable by remember { mutableIntStateOf(1) }
    var role by remember { mutableStateOf(db.role()) }
    MaterialTheme(colorScheme = darkColorScheme(primary=Gold, secondary=Gold, background=Forest, surface=Forest2, onPrimary=Forest, onBackground=Cream, onSurface=Cream)) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(Modifier.fillMaxSize().background(Forest).padding(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                    Column {
                        Text("ترنج", color=Gold, fontSize=27.sp, fontWeight=FontWeight.Bold)
                        Text("مدیریت کافه‌رستوران نارنج", color=Muted, fontSize=11.sp)
                    }
                    Column(horizontalAlignment=Alignment.End) {
                        Text("شبکه محلی • نسخه آزمایشی", color=Gold, fontSize=10.sp)
                        Text(role, color=Cream, fontSize=12.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    listOf("خانه","میزها","سفارش","انبار","هزینه","گزارش","تنظیمات").forEach { label ->
                        val selected = page == label
                        Surface(modifier=Modifier.weight(1f).clickable { page=label }, color=if(selected) Gold else Forest2, shape=RoundedCornerShape(10.dp)) {
                            Text(label, modifier=Modifier.padding(vertical=10.dp), color=if(selected) Forest else Cream, fontSize=10.sp, fontWeight=FontWeight.Bold, textAlign=androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                when(page) {
                    "خانه" -> Dashboard(db, refresh)
                    "میزها" -> TablesScreen(db, refresh, onSelect={ selectedTable=it; page="سفارش" })
                    "سفارش" -> OrderScreen(db, selectedTable, refresh, onChanged={refresh++}, onBack={page="میزها"})
                    "انبار" -> StockScreen(db, refresh, onChanged={refresh++})
                    "هزینه" -> ExpenseScreen(db, refresh, onChanged={refresh++})
                    "گزارش" -> ReportsScreen(db, refresh)
                    else -> SettingsScreen(role, onRole={ role=it; db.setRole(it) })
                }
            }
        }
    }
}

@Composable
fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(color=Forest2, shape=RoundedCornerShape(16.dp), modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(9.dp)) {
            Text(title,color=Gold,fontSize=17.sp,fontWeight=FontWeight.Bold)
            content()
        }
    }
}
@Composable
fun Dashboard(db: ToranjDb, refresh: Int) {
    val tables = remember(refresh) { db.tables() }
    val active = tables.count { it.count > 0 }
    Column(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("داشبورد", color=Cream, fontSize=20.sp, fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Metric("میز فعال","$active از ۲۰")
            Metric("فروش ثبت‌شده",money(db.salesTotal()), Modifier.weight(1f))
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Metric("هزینه‌ها",money(db.expenseTotal()), Modifier.weight(1f))
            Metric("میز آزاد","${20-active}", Modifier.weight(1f))
        }
        Panel("وضعیت برنامه") {
            Text("اطلاعات روی همین گوشی و بدون اینترنت ذخیره می‌شود.", color=Cream)
            Text("همگام‌سازی سه گوشی هنوز فعال نشده و در مرحله بعد اضافه خواهد شد.", color=Muted, fontSize=11.sp)
        }
    }
}
@Composable
fun Metric(label: String, value: String) {
    Surface(color=Forest2, shape=RoundedCornerShape(13.dp), modifier=Modifier.weight(1f)) {
        Column(Modifier.padding(12.dp)) {
            Text(label,color=Muted,fontSize=11.sp)
            Text(value,color=Gold,fontWeight=FontWeight.Bold,fontSize=16.sp)
        }
    }
}
@Composable
fun TablesScreen(db: ToranjDb, refresh: Int, onSelect:(Int)->Unit) {
    val tables = remember(refresh) { db.tables() }
    Column(Modifier.fillMaxSize()) {
        Text("۲۰ میز کافه‌رستوران",color=Cream,fontSize=19.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(columns=GridCells.Fixed(4), verticalArrangement=Arrangement.spacedBy(8.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            items(tables) { t ->
                val busy=t.count>0
                Surface(modifier=Modifier.aspectRatio(0.88f).clickable { onSelect(t.number) }, color=if(busy) Brown else Forest2, shape=RoundedCornerShape(12.dp), border=BorderStroke(1.dp,if(busy) Gold else Color(0xFF37634E))) {
                    Column(Modifier.padding(5.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
                        Icon(Icons.Default.TableRestaurant,null,tint=Gold)
                        Text("میز ${t.number}",color=Cream,fontWeight=FontWeight.Bold,fontSize=12.sp)
                        Text(if(busy) money(t.total) else "آزاد",color=Muted,fontSize=9.sp)
                    }
                }
            }
        }
    }
}
@Composable
fun OrderScreen(db: ToranjDb, table: Int, refresh: Int, onChanged:()->Unit, onBack:()->Unit) {
    val products=remember(refresh) { db.products() }
    val lines=remember(refresh,table) { db.orderLines(table) }
    val total=remember(refresh,table) { db.total(table) }
    var service by remember { mutableStateOf("0") }
    var entry by remember { mutableStateOf("0") }
    var category by remember { mutableStateOf("همه") }
    Column(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
            Text("سفارش میز $table",color=Cream,fontSize=19.sp,fontWeight=FontWeight.Bold)
            TextButton(onClick=onBack) { Text("بازگشت") }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) {
            listOf("همه","غذا","نوشیدنی","پیش‌غذا","قلیان").forEach { c ->
                FilterChip(selected=category==c,onClick={category=c},label={Text(c,fontSize=10.sp)})
            }
        }
        Text("افزودن به سفارش",color=Gold,fontWeight=FontWeight.Bold)
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(5.dp)) {
            items(products.filter { category=="همه" || it.category==category }) { p ->
                Surface(color=Forest2,shape=RoundedCornerShape(10.dp),modifier=Modifier.fillMaxWidth().clickable { db.addItem(table,p); onChanged() }) {
                    Row(Modifier.padding(10.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                        Column { Text(p.name,color=Cream,fontWeight=FontWeight.Bold); Text(p.category,color=Muted,fontSize=10.sp) }
                        Text(money(p.price)+"  +",color=Gold,fontSize=12.sp)
                    }
                }
            }
        }
        Panel("صورتحساب") {
            if(lines.isEmpty()) Text("هنوز آیتمی ثبت نشده است.",color=Muted)
            lines.forEach { (name,data) -> Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text("${name} × ${data.first}",color=Cream); Text(money(data.second),color=Gold) } }
            Text("جمع سفارش: ${money(total)}",color=Cream,fontWeight=FontWeight.Bold)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(service,{service=it},label={Text("سرویس %")},modifier=Modifier.weight(1f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
                OutlinedTextField(entry,{entry=it},label={Text("هزینه ورودی (تومان)")},modifier=Modifier.weight(1f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
            }
            Button(onClick={
                if(total>0) { db.closeOrder(table,(service.toIntOrNull()?:0).coerceIn(0,100),entry.toLongOrNull()?:0); onChanged(); onBack() }
            },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Forest),enabled=total>0) { Text("تسویه و بستن میز") }
        }
    }
}
@Composable
fun StockScreen(db: ToranjDb, refresh:Int, onChanged:()->Unit) {
    var name by remember { mutableStateOf("") }; var qty by remember { mutableStateOf("") }; var unit by remember { mutableStateOf("کیلوگرم") }
    val stock=remember(refresh) { db.stock() }
    Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("انبار مواد اولیه",color=Cream,fontSize=20.sp,fontWeight=FontWeight.Bold)
        Panel("ثبت ورود موجودی") {
            OutlinedTextField(name,{name=it},label={Text("نام ماده اولیه")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(qty,{qty=it},label={Text("مقدار")},modifier=Modifier.weight(1f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
                OutlinedTextField(unit,{unit=it},label={Text("واحد")},modifier=Modifier.weight(1f),singleLine=true)
            }
            Button(onClick={ val q=qty.toDoubleOrNull(); if(name.isNotBlank() && q!=null && q>0) { db.addStock(name.trim(),q,unit); name="";qty="";onChanged() } },colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Forest),modifier=Modifier.fillMaxWidth()) { Text("ثبت ورود کالا") }
        }
        Text("موجودی فعلی",color=Gold,fontWeight=FontWeight.Bold)
        LazyColumn(verticalArrangement=Arrangement.spacedBy(5.dp)) {
            items(stock) { s -> Surface(color=Forest2,shape=RoundedCornerShape(10.dp),modifier=Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween) { Text(s.name,color=Cream); Text("${s.quantity} ${s.unit}",color=Gold) } } }
        }
        Text("کسر خودکار مواد بر اساس دستور پخت هنوز به محصولات متصل نشده است.",color=Muted,fontSize=10.sp)
    }
}
@Composable
fun ExpenseScreen(db:ToranjDb,refresh:Int,onChanged:()->Unit) {
    var title by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("ثبت هزینه",color=Cream,fontSize=20.sp,fontWeight=FontWeight.Bold)
        Panel("هزینه جدید") {
            OutlinedTextField(title,{title=it},label={Text("شرح هزینه")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            OutlinedTextField(amount,{amount=it},label={Text("مبلغ (تومان)")},modifier=Modifier.fillMaxWidth(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
            Button(onClick={ val a=amount.toLongOrNull(); if(title.isNotBlank() && a!=null && a>0) { db.addExpense(title,a);title="";amount="";onChanged() } },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Forest)) { Text("ثبت هزینه") }
        }
        Panel("جمع هزینه‌های ثبت‌شده") { Text(money(db.expenseTotal()),color=Gold,fontSize=20.sp,fontWeight=FontWeight.Bold) }
    }
}
@Composable
fun ReportsScreen(db:ToranjDb,refresh:Int) {
    Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("گزارش مالی",color=Cream,fontSize=20.sp,fontWeight=FontWeight.Bold)
        Panel("خلاصه") {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text("فروش تسویه‌شده",color=Cream); Text(money(db.salesTotal()),color=Gold) }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text("هزینه‌های ثبت‌شده",color=Cream); Text(money(db.expenseTotal()),color=Gold) }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text("مانده قبل از بهای مواد",color=Cream); Text(money(db.salesTotal()-db.expenseTotal()),color=Gold,fontWeight=FontWeight.Bold) }
        }
        Text("گزارش فعلی خلاصه‌ای از کل سوابق محلی است؛ گزارش روزانه و سود واقعی پس از اتصال دستور مصرف مواد تکمیل می‌شود.",color=Muted,fontSize=11.sp)
    }
}
@Composable
fun SettingsScreen(role:String,onRole:(String)->Unit) {
    var selected by remember(role) { mutableStateOf(role) }
    Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("تنظیمات و سطح دسترسی",color=Cream,fontSize=20.sp,fontWeight=FontWeight.Bold)
        Panel("نقش فعال روی این دستگاه") {
            listOf("مدیر","صندوق‌دار","انباردار").forEach { r ->
                Row(Modifier.fillMaxWidth().clickable { selected=r;onRole(r) }.padding(8.dp),verticalAlignment=Alignment.CenterVertically) {
                    RadioButton(selected==r,onClick={selected=r;onRole(r)},colors=RadioButtonDefaults.colors(selectedColor=Gold))
                    Text(r,color=Cream)
                }
            }
        }
        Panel("شبکه و پشتیبان‌گیری") {
            Text("این نسخه اطلاعات را در دیتابیس محلی همین گوشی ذخیره می‌کند.",color=Cream)
            Text("سرور وای‌فای، اتصال سه دستگاه، ورود امن کاربران و پشتیبان‌گیری هنوز نیازمند پیاده‌سازی و آزمایش است.",color=Muted,fontSize=11.sp)
        }
    }
}
